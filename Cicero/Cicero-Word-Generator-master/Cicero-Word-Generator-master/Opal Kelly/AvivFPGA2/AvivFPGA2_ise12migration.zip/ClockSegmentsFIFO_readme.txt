The following files were generated for 'ClockSegmentsFIFO' in directory 
C:\Documents and Settings\Aviv Keshet\My Documents\FPGA\AvivFPGA2:

ClockSegmentsFIFO.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

ClockSegmentsFIFO.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

ClockSegmentsFIFO.sym:
   Please see the core data sheet.

ClockSegmentsFIFO.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

ClockSegmentsFIFO.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

ClockSegmentsFIFO.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

ClockSegmentsFIFO.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

ClockSegmentsFIFO.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

ClockSegmentsFIFO_fifo_generator_v4_4_xst_1.ngc_xst.xrpt:
   Please see the core data sheet.

ClockSegmentsFIFO_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

ClockSegmentsFIFO_readme.txt:
   Text file indicating the files generated and how they are used.

ClockSegmentsFIFO_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

